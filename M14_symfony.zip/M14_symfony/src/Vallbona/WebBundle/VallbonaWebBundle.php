<?php

namespace Vallbona\WebBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class VallbonaWebBundle extends Bundle
{
}
